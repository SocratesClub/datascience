using System;
namespace FePyTest {
   public class IronPythonTest {

      public void greeting() {
         Console.WriteLine("Hello, world!");
      }

   }
}