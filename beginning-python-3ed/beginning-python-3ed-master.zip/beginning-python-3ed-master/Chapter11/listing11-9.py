with open(filename) as f:
    for char in f.read():
        process(char)