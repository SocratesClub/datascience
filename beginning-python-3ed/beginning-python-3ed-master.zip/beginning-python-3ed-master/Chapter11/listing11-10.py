with open(filename) as f:
    for line in f.readlines():
        process(line)