with open(filename) as f:
    for line in f:
        process(line)