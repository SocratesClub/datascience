# Honor the tradition
print("Hello, World!")
